import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../data/models/[feature_name]Model.dart';
import '../data/repository/[feature_name]Repository.dart';
import 'package:injectable/injectable.dart';

@injectable
class Get[feature_name]DataUseCase implements BaseUseCase<[feature_name]Model, [feature_name]Params> {
  final [feature_name]Repository repository;

  const Get[feature_name]DataUseCase(this.repository);

  @override
  Future<Either<ResponseError, [feature_name]Model>> call([feature_name]Params params) {
    return Future.value(Left(ServerFailure()));
  }
}

class [feature_name]Params extends Equatable {
  @override
  List<Object> get props => [];
}
