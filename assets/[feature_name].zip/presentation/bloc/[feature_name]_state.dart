import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

@immutable
abstract class [feature_name]State extends Equatable {}

class Initial[feature_name]State extends [feature_name]State {
  @override
  List<Object> get props => [];
}
