import 'dart:async';

import 'package:bloc/bloc.dart';
import '../../domain/Get[feature_name]DataUseCase.dart';
import 'package:injectable/injectable.dart';

import './bloc.dart';

@injectable
class [feature_name]Bloc extends Bloc<[feature_name]Event, [feature_name]State> {
  final Get[feature_name]DataUseCase get[feature_name]DataUseCase;

  [feature_name]Bloc(this.get[feature_name]DataUseCase) : super(Initial[feature_name]State());


  @override
  Stream<[feature_name]State> mapEventToState(
    [feature_name]Event event,
  ) async* {}
}
