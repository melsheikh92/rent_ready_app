import '../bloc/[feature_name]_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/[feature_name]_state.dart';



class Mobile[feature_name]Screen extends StatefulWidget {
  @override
  _Mobile[feature_name]ScreenState createState() => _Mobile[feature_name]ScreenState();
}

class _Mobile[feature_name]ScreenState extends State<Mobile[feature_name]Screen> {

  @override
  Widget build(BuildContext context) {
    return 
       BlocBuilder<[feature_name]Bloc, [feature_name]State>(
          builder: (context, state) {
            return Container();
          },
        );
  }
}
