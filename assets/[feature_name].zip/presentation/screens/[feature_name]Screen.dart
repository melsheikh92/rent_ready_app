import '../bloc/[feature_name]_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/[feature_name]_state.dart';
import '../Mobile[feature_name]Screen.dart'



class [feature_name]Screen extends StatefulWidget {
  @override
  _[feature_name]ScreenState createState() => _[feature_name]ScreenState();
}

class _[feature_name]ScreenState extends State<[feature_name]Screen> {
  [feature_name]Bloc _bloc;

  @override
  void initState() {
    super.initState();
    _bloc = getIt<[feature_name]Bloc>();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
        create: (_) => _bloc,
        child: BlocBuilder<[feature_name]Bloc, [feature_name]State>(
          builder: (context, state) {
            return  ScreenTypeLayout(
      mobile: Mobile[feature_name]Screen(),
    );
          },
        ));
  }
}
