

class [feature_name]Model{

}