import '../services/[feature_name]Service.dart';
import 'package:injectable/injectable.dart';

import '[feature_name]RemoteDataSource.dart';

@Injectable(as:[feature_name]RemoteDataSource)
@injectable
class [feature_name]RemoteDataSourceImpl implements [feature_name]RemoteDataSource {
  final [feature_name]Service _service;

  const [feature_name]RemoteDataSourceImpl(this._service);
}
