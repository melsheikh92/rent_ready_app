import '../remote/source/[feature_name]RemoteDataSource.dart';
import 'package:injectable/injectable.dart';

import '[feature_name]Repository.dart';

@Injectable(as:[feature_name]Repository)
@injectable
class [feature_name]RepositoryImpl implements [feature_name]Repository {

  final [feature_name]RemoteDataSource remoteDataSource;

  const [feature_name]RepositoryImpl(this.remoteDataSource);

}
